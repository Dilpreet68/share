package com.cg.service;



import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.dao.DiscountDAO;
import com.cg.bean.Discount;





@Service
@Transactional
public class AdminServicesImpl implements AdminServices {
	


	
	@Autowired
	private DiscountDAO discountDAO;

	
	@Override
	@Transactional
	public Discount addDiscount(Discount discount) {
		
		return discountDAO.save(discount);
	}
	
	@Override
	@Transactional
	public void removeDiscount(int discountId) {
		discountDAO.deleteById(discountId);
	}

	

	@Override
	@Transactional
	public List<Discount> findAllDiscounts() {
		return discountDAO.findAll();
	}

	@Override
	public Discount findDiscount(int discountId) {
		// TODO Auto-generated method stub
		return discountDAO.findById(discountId).get();
	}


	
	

	
}
