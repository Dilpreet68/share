package com.cg.service;



import java.util.List;

import com.cg.bean.Discount;







public interface AdminServices {
	
	
	public Discount addDiscount(Discount discount); 
	
	public void removeDiscount(int discountId);
	
	public Discount findDiscount(int discountId);
	
	public List<Discount> findAllDiscounts();
	
}
