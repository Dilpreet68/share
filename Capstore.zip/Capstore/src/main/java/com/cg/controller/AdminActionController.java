package com.cg.controller;



import java.sql.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Discount;
import com.cg.bean.Product;
import com.cg.dao.ProductDAO;
import com.cg.service.AdminServices;
import java.util.Optional;

import javax.annotation.PostConstruct;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AdminActionController {
	
	//MM-dd-yyyy

	@Autowired
	private AdminServices adminService;
	
	@Autowired
	private ProductDAO productDAO;
	
	@PostConstruct
	public void setup() {
		Optional<Product> box = productDAO.findById(8);
		if(box.isPresent()) {
			Product product = box.get();
			Discount d = new Discount(product, 10D, new Date(2019, 8, 10), new Date(2019, 8, 20));
			adminService.addDiscount(d);
		}
	}
	
	
	

   

  // ------------------------------------------------------------------------------------------------------------------------------------ 
	/*
	 * Discount given by admin on particular product
	 * 
	 */
	
	@GetMapping(value = "/findAllDiscounts")
	public List<Discount> findAllDiscounts() {
     
      return adminService.findAllDiscounts();
	}
	
	@GetMapping(value = "/findDiscount/{discountId}")
	public Discount findDiscount(@PathVariable("discountId") int discountId) {
     
      return adminService.findDiscount(discountId);
	}
	
	
	@PostMapping(value = "/addDiscount",consumes= {"application/json"})
	public String addDiscount(@RequestBody Discount discount) {
     
        
		adminService.addDiscount(discount);
		return "Discount Added";
	}

	@DeleteMapping("/deleteDiscount/{discountId}")
	public String removeDiscount(@PathVariable("discountId") int discountId) {
		adminService.removeDiscount(discountId);
		return "Account deleted";
	}
	
	
	
	
	//-----------------------------------------------------------------------------------------------------------------------------------
}
